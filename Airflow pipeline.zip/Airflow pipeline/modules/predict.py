import json
import os
import dill
import pandas as pd
from datetime import datetime
import glob


def predict(latest_model, folder_path, output_csv_path):
    with open(latest_model, 'rb') as file:
        model = dill.load(file)

    # Initialize lists to store results
    predictions = []
    filenames = []

    # Iterate through all .json files in the folder
    for filename in os.listdir(folder_path):
        if filename.endswith(".json"):
            json_path = os.path.join(folder_path, filename)

            # Load the JSON data
            with open(json_path, 'r') as json_file:
                data = json.load(json_file)

            # Convert JSON data to a DataFrame
            df = pd.DataFrame([data])

            filename_without_extension = os.path.splitext(filename)[0]

            # Make predictions using the model
            prediction = model.predict(df)

            # Store results
            predictions.append(prediction[0])
            filenames.append(filename_without_extension)

    # Create a DataFrame from the results
    result_df = pd.DataFrame({'car_id': filenames, 'Price_Category': predictions})

    # Save the DataFrame to a .csv file
    result_df.to_csv(output_csv_path, index=False)

# Specify the directory where your models are stored
model_directory = '../data/models/'

# List all .pkl files in the directory
model_files = glob.glob(os.path.join(model_directory, 'cars_pipe_*.pkl'))

# If there are multiple models, choose the one with the latest timestamp
if model_files:
    latest_model = max(model_files, key=os.path.getctime)
    model_path = latest_model
    print(f"Using the latest model: {model_path}")
else:
    print("No model files found in the specified directory.")

# Example usage:
folder_path = '../data/test/'
output_csv_path = f'../data/predictions/preds_{datetime.now().strftime("%Y%m%d%H%M")}.csv'

if __name__ == '__main__':
    predict(latest_model, folder_path, output_csv_path)
