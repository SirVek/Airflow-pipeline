import datetime as dt
import os
import sys

from airflow.models import DAG
from airflow.operators.python import PythonOperator

# Set the project path
path = os.path.expanduser('~/airflow_hw')

# Add the project path to the Python path
sys.path.insert(0, path)

# Define the DAG arguments
args = {
    'owner': 'airflow',
    'start_date': dt.datetime(2022, 6, 10),
    'retries': 1,
    'retry_delay': dt.timedelta(minutes=1),
    'depends_on_past': False,
}

# Create the DAG instance
with DAG(
        dag_id='car_price_prediction',
        schedule_interval="00 15 * * *",  # Set the desired schedule interval
        default_args=args,
) as dag:

    # Import the pipeline and predict functions here to ensure they are in the Python path
    from modules.pipeline import pipeline
    from modules.predict import predict

    # Define PythonOperators
    pipeline_task = PythonOperator(
        task_id='pipeline',
        python_callable=pipeline,
    )

    predict_task = PythonOperator(
        task_id='predict',
        python_callable=predict,
    )

# Set the task dependencies
pipeline_task >> predict_task
